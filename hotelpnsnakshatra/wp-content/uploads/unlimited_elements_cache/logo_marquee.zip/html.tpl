<div id="{{uc_id}}" class="uc_logo_marquee {{uc_filtering_addclass}}" style="direction:ltr;" {{uc_filtering_attributes|raw}}>
  <div class="uc_marquee uc-items-wrapper" data-widthtype="{{item_width_type}}" data-height="{{box_height}}" data-speed="{{transition_speed}}" data-mobile-items="{{number_of_items_mobile}}" data-tablet-items="{{number_of_items_tablet}}" data-desktop-items="{{number_of_items}}" data-mobile-margin="{{margin_between_items_mobile}}" data-tablet-margin="{{margin_between_items_tablet}}" data-desktop-margin="{{margin_between_items_desktop}}" data-paused="{{autoplay_hover_pause}}" data-direction="{{direction}}">
    {{put_items()}}
  </div>	
</div>
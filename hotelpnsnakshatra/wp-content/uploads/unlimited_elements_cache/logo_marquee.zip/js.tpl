{{ ucfunc("put_docready_start") }}
		
  var objWrapper = jQuery('#{{uc_id}}');
  
  //show widget after js load
  objWrapper.css("opacity", "1");
  
  var objMarquee = objWrapper.find('.uc_marquee');
  
  setTimeout(function(){
    UCMarquee(objMarquee);    
  },500);
  
  objWrapper.on("uc_ajax_refreshed",function(){
    UCMarquee(objMarquee);     
  });

    	
{{ ucfunc("put_docready_end") }}
<div class="uc_logo_marquee_holder {{item.item_repeater_class}}">
	  {% if enable_link == "true" %}<a href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>{% endif %}
      <img {% if item.image is not empty %}src="{{item.image}}"{% else %}src="{{uc_assets_url}}/fallback-img.jpg"{% endif %} alt="{{item.title|raw}}" class="ue_img_marquee">
      {% if show_title == "true" %}<div class="ue_marquee_title">{{item.title|raw}}</div>{% endif %}	
      {% if item.badge is empty %}  
      {% else %} 
          <div class="ue-item-badge">{{item.badge|raw}}</div>  
      {% endif %}	
      {% if enable_link == "true" %}</a>{% endif %}
</div>
#{{uc_id}}{
  min-height:1px;
  text-align: center;
  position:relative;
  opacity: 0;
}

#{{uc_id}} *{
  box-sizing:border-box;
}

#{{uc_id}} .uc_marquee {
	display: flex;
	align-items: center;
	overflow: hidden;
    position: relative;
}

#{{uc_id}} .uc_marquee > div {
    position:relative;
	display: inline-flex;
	align-items: center;
	flex: 0 0 auto;
	width: auto;
	overflow: hidden;
  	{% if direction == "left" %}
		animation-name: marquee-to-left;
    {% elseif direction == "right" %}
    	animation-name: marquee-to-right;
    {% elseif direction == "up" %}
    	animation-name: marquee-to-up;
    {% elseif direction == "down" %}
    	animation-name: marquee-to-down;
    {% endif %}
	animation-timing-function: linear;
	animation-iteration-count: infinite;
    {% if direction == "up" or direction == "down" %}
      	flex-direction: column;
  		width: 100%;
    {% endif %}
}

#{{uc_id}} img{
  	height: 100%;
}

#{{uc_id}} .ue_marquee_title{
  position:absolute;
  bottom:0px;
  left: 0;
  width:100%;
}

#{{uc_id}} .uc_logo_marquee_holder{
	position:relative;
    text-align:center;
    overflow:hidden;
    {% if item_width_type == "dynamic" %}
      width: auto;
      display: inline-flex;
      justify-content: center;
    {% endif %}
}

{% if direction == "up" or direction == "down" %}
  #{{uc_id}} .uc_logo_marquee_holder{
      width: 100%;
  }
{% endif %}

#{{uc_id}} .uc_logo_marquee_holder a{
  height:100%;
  width: 100%;
  display:flex;
  align-items: center;
  justify-content:center;
}

{% if direction == "left" %}
  @keyframes marquee-to-left {
	from {transform: translate(0,0)}
	to {transform: translate(-50%,0)}
  }
{% endif %}	

{% if direction == "right" %}
  @keyframes marquee-to-right {
	from {transform: translate(-50%,0)}
	to {transform: translate(0,0)}
  }
{% endif %}

{% if direction == "up" %}
  @keyframes marquee-to-up {
	from {transform: translate(0, 25%)}
	to {transform: translate(0, -25%)}
  }
{% endif %}

{% if direction == "down" %}
  @keyframes marquee-to-down {
	from {transform: translate(0, -25%)}
	to {transform: translate(0, 25%)}
  }
{% endif %}

#{{uc_id}} .ue-item-badge{
  position:absolute;
  {{badge_horizontal_snap}}:{{badge_horizontal_offset}}px;
  {{badge_vertical_snap}}:{{badge_vertical_offset}}px;
}